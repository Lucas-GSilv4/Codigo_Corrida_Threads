package org.example;

import java.util.concurrent.ThreadLocalRandom;

public class Carro implements Runnable{

    String nome;
    double distanciaTotalPercorrida = 1000;
    double distanciaPercorrida = 0;

    public Carro(String nome, double distanciaTotalPercorrida) {
        this.nome = nome;
        this.distanciaTotalPercorrida = distanciaTotalPercorrida;
    }

    @Override
    public void run() {
        while (distanciaPercorrida < distanciaTotalPercorrida){
            int avanco = ThreadLocalRandom.current().nextInt(1,20);
            distanciaPercorrida += avanco;

            if (distanciaPercorrida > distanciaTotalPercorrida) {
                distanciaPercorrida = distanciaTotalPercorrida;
            }

            System.out.printf("%s andou %d metros e já percorreu %.0f de %.0f metros.%n",
                    nome, avanco, distanciaPercorrida, distanciaTotalPercorrida);

            try {
                Thread.sleep(ThreadLocalRandom.current().nextInt(100, 500));
            } catch (InterruptedException e) {
                System.out.println(nome + " foi interrompido.");
                Thread.currentThread().interrupt();
                return;
            }
        }

        System.out.println("[CHEGADA] O " + nome + " cruzou a linha de chegada!");
        System.out.println("O carro "+ nome + " venceu a corrida!");
        System.exit(0);
    }
}
